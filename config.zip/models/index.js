const Models = {
    usersModel: require('./nosql/users')
}

module.exports = Models;